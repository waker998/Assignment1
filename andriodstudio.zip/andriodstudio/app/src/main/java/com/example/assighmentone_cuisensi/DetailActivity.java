package com.example.assighmentone_cuisensi;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_INDEX = "index";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        int index = getIntent().getIntExtra(EXTRA_INDEX, 0);

        // 顶部图标资源（和首页一致）
        int[] icons = {
                R.drawable.img_btn_facilities,
                R.drawable.img_btn_events,
                R.drawable.img_btn_clubs,
                R.drawable.img_btn_support
        };

        // 读取标题、长文本（确保 arrays.xml 中有）
        String[] titles = getResources().getStringArray(R.array.string_array_titles);
        String[] contents = getResources().getStringArray(R.array.string_array_content);

        ImageView icon = findViewById(R.id.detailIcon);
        TextView title = findViewById(R.id.detailTitle);
        TextView desc  = findViewById(R.id.detailDescription);

        icon.setImageResource(icons[index]);
        title.setText(titles[index]);
        desc.setText(contents[index]);   // 显示长文本
    }
}
