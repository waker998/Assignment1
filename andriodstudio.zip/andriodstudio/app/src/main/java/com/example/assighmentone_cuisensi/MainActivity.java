package com.example.assighmentone_cuisensi;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // 四个按钮共用：不使用 if/switch，直接读取 tag 作为 index
    public void onTileClicked(View v) {
        Object tag = v.getTag();
        if (tag == null) return;
        int index = Integer.parseInt(String.valueOf(tag));

        // Part E: Toast（标题来自 arrays.xml）
        String[] titles = getResources().getStringArray(R.array.string_array_titles);
        String title = (index >= 0 && index < titles.length) ? titles[index].trim() : "Clicked";
        Toast.makeText(this, title + " clicked", Toast.LENGTH_SHORT).show();

        // Part G: 显式 Intent + 传 index
        Intent it = new Intent(this, DetailActivity.class);
        it.putExtra("index", index);
        startActivity(it);
    }
}
